var express = require('express');
var router = express.Router();

let movie = [{
    id: 1,
    director: 'James Cameron',
    title:'Avatar'
}]

/* GET home page. */
router.get('/',(req, res)=> {
  res.json(movie);
});
router.get('/:id', (req,res)=>{
    res.send(req.params.id)
})

module.exports = router;