var express = require('express');
var router = express.Router();
var uuid = require ('uuid')

let movie = [
  {id: 1,director: 'James Cameron',title:'Avatar'},
  {id: 2,director: 'James Cameron',title:'Try lies'}
]

/* GET home page. */
router.get('/',(req, res)=> {
  res.json(movie);
});
router.get('/:id', (req,res)=>{
    const filmID = parseInt(req.params.id, 10)

    const film = movie.find(film=> film.id===filmID)

    if(film) {
      return res.json (film)
    };
    return res.status (404).json({
      status: `Фильм ${filmID} не найден`

      
    })

    router.post('/', (req,res)=>{
        console.log(req.body)
        const film = {
          id: uuid(),
          director: req.body,director,
          title: req.body.title,
        }
        return res.json(film)
    })
})

module.exports = router;